$(window).ready(()=>{
    console.log("hi")
})