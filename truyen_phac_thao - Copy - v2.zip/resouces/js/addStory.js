function addNewStory()
{
    window.location.href="newStory.html";
}
function addMyStory()
{
    window.location.href="myStory.html";

}
$(".coverLoader").hide()
